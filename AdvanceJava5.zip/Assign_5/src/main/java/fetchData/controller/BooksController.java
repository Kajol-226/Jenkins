package fetchData.controller;

import java.io.IOException;
//import java.net.http.HttpRequest;import java.net.http.HttpResponse;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import fetchData.entity.Book;
import fetchData.services.AuthorServices;
import fetchData.services.BookServices;
import fetchData.services.LibrarianServices;

@Controller
public class BooksController {

	@Autowired
	BookServices bs;

	@Autowired
	AuthorServices as;
	
	@Autowired
	LibrarianServices ls;

	@RequestMapping("/getbook")
	public ModelAndView getAllBooks() {
		ModelAndView mv = new ModelAndView();
		mv.addObject("listOfBooks", bs.getAllbooks());
		mv.addObject("listOfAuthors", as.getAllAuthor());
		mv.setViewName("Books.jsp");
		return mv;
	}
	@RequestMapping("/editbook")
	public ModelAndView editBook(){
		ModelAndView mv = new ModelAndView();
		mv.addObject("listOfBooks", bs.getAllbooks());
		mv.addObject("listOfAuthors", as.getAllAuthor());
		mv.setViewName("addBook.jsp");
		return mv;
		
	}

	@RequestMapping("/addBook")
	public void createBook(HttpServletResponse response, HttpServletRequest request) throws IOException {

		String id = request.getParameter("bId");
		String bname = request.getParameter("bookName");
		String authID = request.getParameter("authorId");
		Integer authorId = Integer.parseInt(authID);
		String authorName = as.getAuthorName(authID);

		Book bd = new Book();
		bd.setAuthorId(authorId);
		bd.setAuthorName(bname);
		bd.setbId(Integer.parseInt(id));
		bd.setBookName(authorName);

		if (bs.isBookexist(bd, bs.getAllbooks())) {
			bs.deleteBook(id);
			bs.createBook(bd);
			response.sendRedirect("/fetchData/getbook");
		} else {
			bs.createBook(bd);
			response.sendRedirect("/fetchData/getbook");
		}

	}

	@RequestMapping("/delete")
	public void deleteBook(HttpServletResponse response, HttpServletRequest request) throws IOException {
		String id = request.getParameter("delBookID");
		bs.deleteBook(id);
		response.sendRedirect("/fetchData/getbook");
	}
	@RequestMapping("/verifyUser")
	public void login(HttpServletResponse response, HttpServletRequest request) throws IOException {
		String email = request.getParameter("email");
		String pass = request.getParameter("password");
		
		if(ls.checkLibrarian(email, pass)) {
			response.sendRedirect("/fetchData/getbook");
		}else {
			response.sendRedirect("/fetchData/invalidCredentials");
		}
		
		
	}
	@RequestMapping("/invalidCredentials")
	public ModelAndView invalidLib() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("invalid.jsp");
		return mv;
	}
	
	@RequestMapping("/logout")
	public void logout(HttpServletResponse response, HttpServletRequest request) throws IOException {
		response.sendRedirect("/fetchData");
	}
	
	@RequestMapping("/edit")
	public void edit(HttpServletResponse response, HttpServletRequest request) throws IOException {
		response.sendRedirect("/editbook");
	}
	
	
	
	

}
