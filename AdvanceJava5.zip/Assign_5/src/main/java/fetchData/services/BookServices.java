package fetchData.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;
import fetchData.entity.Book;

@Service
public class BookServices {

	// @Autowired(required=true)
	private RestTemplate restTemplate = new RestTemplate();

	public List<Book> getAllbooks() {

		String resourceUrl = "http://localhost:7080/book";
		Book[] bs = restTemplate.getForObject(resourceUrl, Book[].class);

		List<Book> listBooks = Arrays.asList(bs);
		return listBooks;
	}

	public void createBook(Book bookDetails) {

		restTemplate.postForObject("http://localhost:7080/book", bookDetails, Book.class);

	}

	public void deleteBook(String bcode) {

		restTemplate.delete("http://localhost:7080/book/" + bcode);
	}

	public void updateBook(Book bd) {

		restTemplate.put("http://localhost:7080/book", bd);
	}

	public boolean isBookexist(Book bd, List<Book> ls) {

		for (Book fd : ls) {

			if (fd.getbId() == bd.getbId()) {
				return true;
			}
		}

		return false;
	}

}
