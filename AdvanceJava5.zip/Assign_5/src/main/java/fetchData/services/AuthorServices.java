package fetchData.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.util.JSONPObject;

import fetchData.entity.Author;
import fetchData.entity.Book;


@Service
public class AuthorServices {
	private RestTemplate restTemplate = new RestTemplate();
	
    public List<Author> getAllAuthor(){
		
        String resourceUrl = "http://localhost:7080/author";
        Author[] authorArray = restTemplate.getForObject(resourceUrl, Author[].class);
      
		List<Author>listAuthor= Arrays.asList(authorArray);
		return listAuthor;
	}
    public String getAuthorName(String id) {
    	String resourceUrl = "http://localhost:7080/author/"+id+"/";
    	Author author= restTemplate.getForObject(resourceUrl, Author.class);
    	return author.getName();
    }

}
