package fetchData.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.util.JSONPObject;

import fetchData.entity.Author;
import fetchData.entity.Librarian;



@Service
public class LibrarianServices {
	private RestTemplate restTemplate = new RestTemplate();
	
    public boolean checkLibrarian(String email,String pass) {
    	
    	String resourceUrl = "http://localhost:7080/librarian/"+email;
    	Librarian lib= restTemplate.getForObject(resourceUrl, Librarian.class);
    	
    	// lib.printDetails();
    	if(lib!=null) {
    		if(lib.getPassword().equals(pass)) {
    			return true;
    		}
    	}
    	
    	
    	return false;
    }

}